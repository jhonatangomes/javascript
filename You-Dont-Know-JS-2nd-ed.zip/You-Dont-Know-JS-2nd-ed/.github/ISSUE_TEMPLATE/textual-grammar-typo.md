---
name: Textual/Grammar Typo
about: Help us correct a spelling or grammar error in the text.
labels:

---

**We are not currently accepting any more corrections to the book content. The 2nd edition books have all been published and finalized. Thank you for your interest and support.**
