---
name: Report Technical Mistake
about: Help us fix a mistake in the code.
labels:

---

**We are not currently accepting any more corrections to the book content. The 2nd edition books have all been published and finalized. Thank you for your interest and support.**
